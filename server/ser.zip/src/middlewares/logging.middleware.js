//some logging of request and resonse could have been done here
