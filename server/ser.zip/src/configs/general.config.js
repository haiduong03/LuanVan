/** @format */

const general = {
	listPerPage: 15,
};

module.exports = general;
